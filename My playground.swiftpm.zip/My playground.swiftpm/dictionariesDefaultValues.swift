//
//  File.swift
//  My playground
//
//  Created by Luis Carlos Hernandez on 13/03/22.
//

import UIKit

//Si intentas leer un valor de un diccionario usando una clave que no existe, Swift te devolverá nil, nada en absoluto. Si bien esto puede ser lo que quieres, hay una alternativa: podemos proporcionar al diccionario un valor predeterminado para usar si solicitamos una clave que falta.
let favoriteIceCream = [
    "Paul": "Chocolate",
    "Sophie": "Vanilla"
]

//favoriteIceCream["Charlotte"]


//De esta manera no0s arroja un valor "nil"

favoriteIceCream["Charlotte", default: "Unknown"]
//De esta forma nos arroja un valor "unknown" en vez de "nil "

