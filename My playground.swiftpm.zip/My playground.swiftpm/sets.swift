//
//  File.swift
//  My playground
//
//  Created by Luis Carlos Hernandez on 13/03/22.
//

import UIKit

//Los conjuntos se ordenande manera aleatroria y no se pueden repetir un elemento( si se incluye el sistema igual solo incluira valores distintos)

let colors = Set(["red", "green", "blue"])
// "set" determina el inicio con parentesis y corchetes ([
let colors2 = Set(["red", "green", "blue", "red", "blue"])
// lo antes mencionado, se incluyenm dos red y dos blue pero en consola unicamente se veran un valor de cada uno.
