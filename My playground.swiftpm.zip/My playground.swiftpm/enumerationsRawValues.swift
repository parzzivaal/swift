//
//  File.swift
//  My playground
//
//  Created by Luis Carlos Hernandez on 13/03/22.
//

import UIKit

//A veces es necesario poder asignar valores a las enumeraciones para que tengan significado. Esto te permite crearlos de forma dinámica y también utilizarlos de diferentes maneras


//Por ejemplo, puede crear una enumeración Planet que almacene valores enteros para cada uno de sus casos
enum Planet: Int {
    case mercury
    case venus
    case earth
    case mars
}

//Swift en automatico asignara una posicion comenzando desde cero, y puedes utilizar esa posicion para crear una instancia del caso de enumeración apropiado. Por ejemplo, a la tierra se le dará el número 2, así que puedes escribir esto:
let earth = Planet(rawValue: 2)

//Si lo desea, puede asignar a uno o más casos un valor específico, y Swift generará el resto. No es muy natural que pensemos en la Tierra como el segundo planeta, así que podrías escribir esto:

enum Planet2: Int {
    case mercury = 1
    case venus
    case earth
    case mars
}
// Ene este caso se le asigno a mercuriuo el numero uno y partira de ahi el conteo
