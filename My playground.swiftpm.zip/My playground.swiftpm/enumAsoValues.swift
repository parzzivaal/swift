//
//  File.swift
//  My playground
//
//  Created by Luis Carlos Hernandez on 13/03/22.
//

import UIKit

//Además de almacenar un valor simple, las enumeraciones también pueden almacenar valores asociados adjuntos a cada caso. Esto le permite adjuntar información adicional a sus enumeraciones para que puedan representar datos más matizados

//Por ejemplo, podríamos definir una enumeración que almacene varios tipos de actividades:

// enum Activity {
//    case bored
//    case running
//    case talking
//    case singing
// }

//Eso nos permite decir que alguien está hablando, pero no sabemos de qué está hablando, o podemos saber que alguien está corriendo, pero no sabemos a dónde está corriendo.Los valores asociados a Enum nos permiten añadir esos detalles adicionales:
enum Activity {
    case bored
    case running(destination: String)
    case talking(topic: String)
    case singing(volume: Int)
}

//Ahora podemos ser más precisos, podemos decir que alguien está hablando de fútbol:

let talking = Activity.talking(topic: "football")

