//
//  File.swift
//  My playground
//
//  Created by Luis Carlos Hernandez on 13/03/22.
//

import UIKit
//Has llegado al final de la segunda parte de esta serie, así que vamos a resumir:
//
//Los arrays, sets, tuples y diccionarios te permiten almacenar un grupo de artículos bajo un solo valor. Cada uno de ellos lo hace de diferentes maneras, por lo que lo que utilice depende del comportamiento que desee.
//Los arrays almacenan los artículos en el orden en que los añades y accedes a ellos mediante posiciones numéricas.
//Establece los artículos de la tienda sin ningún pedido, por lo que no puedes acceder a ellos usando posiciones numéricas.
//Las tuplas son de tamaño fijo y puedes adjuntar nombres a cada uno de sus artículos. Puedes leer elementos usando posiciones numéricas o usando tus nombres.
//Los diccionarios almacenan los elementos de acuerdo con una clave, y puedes leerlos usando esas teclas.
//Las enumeraciones son una forma de agrupar valores relacionados para que puedas usarlos sin errores ortográficos.
//Puede adjuntar valores sin procesar a las enumeraciones para que se puedan crear a partir de enteros o cadenas, o puede añadir valores asociados para almacenar información adicional sobre cada caso.
