//
//  File.swift
//  My playground
//
//  Created by Luis Carlos Hernandez on 13/03/22.
//

import UIKit

//Las matrices, conjuntos y diccionarios se denominan colecciones, porque recopilan valores juntos en un solo lugar.

//Si quieres crear una colección vacía, solo tienes que escribir su tipo seguido de los paréntesis de apertura y cierre. Por ejemplo, podemos crear un diccionario vacío con cadenas para claves y valores como este:
var teams = [String: String]()

//Luego podemos añadir entradas más adelante, así:
teams["Paul"] = "Red"

//Del mismo modo, puedes crear un array (arreglo) vacía para almacenar enteros como este
var results = [Int]()

//La excepción es crear un set(conjunto) vacío, que se hace de forma diferente:
var words = Set<String>()
var numbers = Set<Int>()

//Esto se debe a que Swift tiene una sintaxis especial solo para diccionarios y Arrays ; otros tipos deben usar la sintaxis de corchetes angulares como conjuntos. Si lo deseas, puedes crear matrices y diccionarios con una sintaxis similar:
var scores = Dictionary<String, Int>()
var results = Array<Int>()
