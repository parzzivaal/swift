//
//  File.swift
//  My playground
//
//  Created by Luis Carlos Hernandez on 13/03/22.
//

import UIKit

//Los diccionarios son colecciones de valores al igual que las matrices, pero en lugar de almacenar cosas con una posición entera, puedes acceder a ellas usando lo que quieras.
let heights = [
    "Taylor Swift": 1.78,
    "Ed Sheeran": 1.73
]
// A diferencia de las tuples, estos inician con corchete

heights ["Taylor Swift"]

//Al igual que las matrices, los diccionarios comienzan y terminan con corchetes y cada elemento se separa con una coma. Sin embargo, también utilizamos dos puntos para separar el valor que desea almacenar (p. ej. 1.78) del identificador en el que desea almacenarlo (p. ej. «Taylor Swift»).Estos identificadores se llaman claves y puedes usarlos para volver a leer datos del diccionario
