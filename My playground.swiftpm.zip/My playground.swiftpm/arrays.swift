//
//  File.swift
//  My playground.swiftpm
//
//  Created by Luis Carlos Hernandez on 13/03/22.
//

import UIKit

var saludo = "hola mundo"
let john = "John Lennon"
let paul = "Paul McCartney"
let george = "George Harrison"
let ringo = "Ringo Starr"

let beatles = [john, paul, george, ringo]



