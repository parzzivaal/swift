//
//  File.swift
//  My playground
//
//  Created by Luis Carlos Hernandez on 13/03/22.
//

import UIKit

//Tuple
let address = (house: 555, street: "Taylor Swift Avenue", city: "Nashville")
//i necesitas una colección específica y fija de valores relacionados en la que cada elemento tenga una posición o un nombre precisos, debes usar una tupla

//set(conjunto)
let set = Set(["aardvark", "astronaut", "azalea"])
//Si necesitas una colección de valores que deben ser únicos o necesitas poder comprobar si un elemento específico está ahí extremadamente rápido, deberías usar un conjunto

//array
let pythons = ["Eric", "Graham", "John", "Michael", "Terry", "Terry"]
//Si necesita una colección de valores que puedan contener duplicados, o el orden de sus elementos es importante, debe utilizar un array( arreglo)
