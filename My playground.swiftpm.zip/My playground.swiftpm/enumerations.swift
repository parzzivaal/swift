//
//  File.swift
//  My playground
//
//  Created by Luis Carlos Hernandez on 13/03/22.
//

import UIKit

//Las enumeraciones, generalmente llamadas solo enumeraciones, son una forma de definir grupos de valores relacionados de una manera que los hace más fáciles de usar.

//Por ejemplo, si quisieras escribir algo de código para representar el éxito o el fracaso de algún trabajo que estabas haciendo, podrías representarlo como cadenas:
let result = "failure"

//Pero, ¿qué pasa si alguien utiliza accidentalmente nombres diferentes?
let result2 = "failed"
let result3 = "fail"

//Esas tres son cuerdas diferentes, por lo que significan cosas diferentes.
enum Result {
    case success
    case failure
}
//Y ahora, cuando lo usamos, debemos elegir uno de esos dos valores:
let result4 = Result.failure

//Esto te impide usar accidentalmente diferentes strings cada vez.
